package com.dst.dt203657.sharearide;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
import android.os.AsyncTask;
//import org.springframework.web.client.RestTemplate;

import java.util.List;


public class MainActivity extends Activity  {

    Button offerARideBtn;
    Button optARideBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        offerARideBtn = (Button) findViewById(R.id.button);
        optARideBtn = (Button) findViewById(R.id.button2);
        offerARideBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                System.out.println("Inside Offer a Ride Button click listener");
                Intent intent = new Intent(MainActivity.this, OfferARideActivity.class);
                startActivity(intent);
            }
        });
        optARideBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {

            }
        });
    }

/*    private class HttpRequestTask extends AsyncTask<Void, Void, List<RideOfferList>> {
        @Override
        protected List<RideOfferList> doInBackground(Void... params) {
            try {
                final String url = "http://rest-service.guides.spring.io/greeting";
                RestTemplate restTemplate = new RestTemplate();
                restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
                Greeting greeting = restTemplate.getForObject(url, Greeting.class);
                return greeting;
            } catch (Exception e) {
                Log.e("MainActivity", e.getMessage(), e);
            }

            return null;
        }

        @Override
        protected void onPostExecute(Greeting greeting) {
            TextView greetingIdText = (TextView) findViewById(R.id.id_value);
            TextView greetingContentText = (TextView) findViewById(R.id.content_value);
            greetingIdText.setText(greeting.getId());
            greetingContentText.setText(greeting.getContent());
        }

    }*/
}
