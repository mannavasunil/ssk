package com.dst.dt203657.sharearide;

import java.util.Date;

/**
 * Created by dt203657 on 9/23/2016.
 */
public class RideOfferList {

    private String riderName;

    private String seatsOffering;

    private String vehicleNumber;

    private Date riderStartTime;

    private String meetingPoint;

    private String destinationPoint;

    private String phoneNumber;

    private String viaRouteInfo;

    public String getRiderName() {
        return riderName;
    }

    public void setRiderName(String riderName) {
        this.riderName = riderName;
    }

    public String getSeatsOffering() {
        return seatsOffering;
    }

    public void setSeatsOffering(String seatsOffering) {
        this.seatsOffering = seatsOffering;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public Date getRiderStartTime() {
        return riderStartTime;
    }

    public void setRiderStartTime(Date riderStartTime) {
        this.riderStartTime = riderStartTime;
    }

    public String getMeetingPoint() {
        return meetingPoint;
    }

    public void setMeetingPoint(String meetingPoint) {
        this.meetingPoint = meetingPoint;
    }

    public String getDestinationPoint() {
        return destinationPoint;
    }

    public void setDestinationPoint(String destinationPoint) {
        this.destinationPoint = destinationPoint;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getViaRouteInfo() {
        return viaRouteInfo;
    }

    public void setViaRouteInfo(String viaRouteInfo) {
        this.viaRouteInfo = viaRouteInfo;
    }
}
