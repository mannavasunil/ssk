package com.sharearide.config;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sharearide.util.RestResponse;
@ControllerAdvice
public class ShareARideExceptionHandler {

private static final Logger logger = Logger.getLogger(ShareARideExceptionHandler.class);
	
	@ExceptionHandler(Exception.class)
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public RestResponse exception(Exception e) throws JsonProcessingException {
		logger.error("::::::share-a-ride::::",e);
		final RestResponse restResponse = new RestResponse();
		restResponse.setData(null);
		restResponse.setError(e.getLocalizedMessage());
		return restResponse;
	}
	
}
