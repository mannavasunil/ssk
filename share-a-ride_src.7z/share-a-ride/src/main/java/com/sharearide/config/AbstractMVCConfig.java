package com.sharearide.config;

import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
@ComponentScan(basePackages = {"com.sharearide.web"})
public class AbstractMVCConfig extends WebMvcConfigurerAdapter {
	 @Override
	    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
	        super.configureMessageConverters(converters);
	        ShareARideMappingJackson2HttpMessageConverter jacksonMessageConverter = new ShareARideMappingJackson2HttpMessageConverter();
	        converters.add(jacksonMessageConverter);
	    }
}
