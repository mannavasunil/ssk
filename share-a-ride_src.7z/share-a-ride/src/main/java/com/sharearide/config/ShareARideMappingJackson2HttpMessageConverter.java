package com.sharearide.config;

import java.io.IOException;

import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;

import com.sharearide.util.RestResponse;
@Component
public class ShareARideMappingJackson2HttpMessageConverter extends
		MappingJackson2HttpMessageConverter {
	@Override
	protected void writeInternal(Object object, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		if (object instanceof RestResponse) {
			super.writeInternal(object, outputMessage);
		} else {
			final RestResponse restResponse = new RestResponse();
			restResponse.setData(object);
			restResponse.setError("");
			super.writeInternal(restResponse, outputMessage);
		}
	}

}
