package com.sharearide.services;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sharearide.dao.OfferARideDAO;
import com.sharearide.model.OfferARideDTO;
@Service
public class OfferARideServiceImpl implements OfferARideService {

	private final static Logger logger = Logger.getLogger(OfferARideServiceImpl.class);

	@Autowired
	private OfferARideDAO offerARideDAO;

	@Override
	public boolean insertOfferARide(OfferARideDTO offerARide) {
		if (logger.isDebugEnabled())
			logger.debug("  OfferARideServiceImpl.insertOfferARide  "+ offerARide.toString());
		
		return offerARideDAO.insertOfferARide(offerARide);
	}

	@Override
	public List<OfferARideDTO> getOfferedRides(String pickupLoc, String dropLoc) {
		if (logger.isDebugEnabled())
			logger.debug("  OfferARideServiceImpl.getOfferedRides  pickupLoc   "+ pickupLoc + "  dropLoc  " + dropLoc);
		
		
		return offerARideDAO.getOfferedRides(pickupLoc, dropLoc);
	}

	@Override
	public List<OfferARideDTO> getMyOptedRides(BigInteger opterMobileNumber) {
		
		if (logger.isDebugEnabled())
			logger.debug("  OfferARideServiceImpl.getMyOptedRides  OpterMobileNumber   "+ opterMobileNumber); 
		
		
		return offerARideDAO.getMyOptedRides(opterMobileNumber);
	}

}
