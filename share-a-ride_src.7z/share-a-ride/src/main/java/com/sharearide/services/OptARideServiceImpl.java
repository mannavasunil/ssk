package com.sharearide.services;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sharearide.dao.OptARideDAO;
import com.sharearide.model.OptARideDTO;
@Service
public class OptARideServiceImpl implements OptARideService {

	private final static Logger logger = Logger.getLogger(OptARideServiceImpl.class);
	
	@Autowired
	private OptARideDAO optARideDAO;

	@Override
	public boolean insertOptARide(OptARideDTO optARide) {
		if (logger.isDebugEnabled())
			logger.debug(" OptARideServiceImpl " + optARide.toString());
		
		return optARideDAO.insertOptARide(optARide);
	}

	@Override
	public List<OptARideDTO> getOptedRides(BigInteger mobileNumber) {
		if (logger.isDebugEnabled())
			logger.debug("  OptARideServiceImpl  " + mobileNumber);
		
		return optARideDAO.getOptedRides(mobileNumber);
	}

}
