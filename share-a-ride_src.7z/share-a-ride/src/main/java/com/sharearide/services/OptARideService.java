package com.sharearide.services;

import java.math.BigInteger;
import java.util.List;

import com.sharearide.model.OptARideDTO;

public interface OptARideService {
	
	public boolean insertOptARide(OptARideDTO optARide);

	public List<OptARideDTO> getOptedRides(final BigInteger mobileNumber);
}
