package com.sharearide.util;

import org.springframework.util.StringUtils;

import com.sharearide.model.OfferARideDTO;
import com.sharearide.model.OptARideDTO;

public abstract class ValidationUtils {

	public static void validateOfferARideData(OfferARideDTO offerARideDTO) {
		if (!StringUtils.hasText(offerARideDTO.getDropLocation())) {
			throw new RuntimeException("Destination/Drop point is required.");
		}
		if (!StringUtils.hasText(offerARideDTO.getPickupLocation())) {
			throw new RuntimeException("Source/Pick Up point is required.");
		}
		if (!StringUtils.hasText(offerARideDTO.getStartTime())) {
			throw new RuntimeException("Start time is required.");
		}
		if (!StringUtils.hasText(offerARideDTO.getVehicleNumber())) {
			throw new RuntimeException("Vehicle number is required.");
		}
		if (!StringUtils.hasText(offerARideDTO.getMeetingPoint())) {
			throw new RuntimeException("Meeting point is required.");
		}
		if (!StringUtils.hasText(offerARideDTO.getViaRoute())) {
			throw new RuntimeException("Via route information is required.");
		}
		if (!StringUtils.hasText(String.valueOf(offerARideDTO.getOfferedSeats()))) {
			throw new RuntimeException("Offered seats is required.");
		}
		if (!StringUtils.hasText(String.valueOf(offerARideDTO.getMobileNumber()))) {
			throw new RuntimeException("Mobile number is required.");
		}
	}

	public static void validateOptARideData(OptARideDTO optARideDTO) {
		if (!StringUtils.hasText(String.valueOf(optARideDTO.getOptedRideId()))) {
			throw new RuntimeException("Opted ride id is required.");
		}
		if (!StringUtils.hasText(String.valueOf(optARideDTO.getOpterMobileNumber()))) {
			throw new RuntimeException("Opter mobile number is required.");
		}
	}
}
