package com.sharearide.util;

import java.sql.Timestamp;

public abstract class AppUtils {
	public static Timestamp getTimestamp() {
		return new Timestamp((new java.util.Date()).getTime());
	}

	public static RestResponse buildRestResponse(Object obj) {
		final RestResponse restResponse = new RestResponse();
		restResponse.setData(obj);
		restResponse.setError("");
		return restResponse;
	}
}
