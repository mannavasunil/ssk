package com.sharearide.dao;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sharearide.model.OfferARideDTO;
import com.sharearide.util.AppUtils;

@Repository
public class OfferARideDAOImpl implements OfferARideDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@Transactional
	public boolean insertOfferARide(OfferARideDTO offerARide) {

		if (getRiderMobileNumberActiveRidesCount(offerARide.getMobileNumber()) > 0) {
			inActivateOldRidesOfAMobileNumber(offerARide.getMobileNumber());
		}
		String insertStmt = "INSERT INTO ride_offers (rider_name,start_time,offered_seats,vehicle_number ,meeting_point,mobile_number,pickup_location,drop_location,via_route,createdDate,updatedDate,createdBy,updatedBy ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		final Object[] params = new Object[] { offerARide.getRiderName(),
				offerARide.getStartTime(), offerARide.getOfferedSeats(),
				offerARide.getVehicleNumber(), offerARide.getMeetingPoint(),
				offerARide.getMobileNumber(), offerARide.getPickupLocation(),
				offerARide.getDropLocation(), offerARide.getViaRoute(),
				AppUtils.getTimestamp(), AppUtils.getTimestamp(),
				offerARide.getMobileNumber(), offerARide.getMobileNumber() };
		int insertCount = jdbcTemplate.update(insertStmt, params);
		return insertCount > 0 ? true : false;
	}

	private int inActivateOldRidesOfAMobileNumber(BigInteger riderMobileNumber) {
		String sqlStmt = "UPDATE ride_offers SET is_active=0 WHERE is_active=1 AND mobile_number="
				+ riderMobileNumber;
		return jdbcTemplate.update(sqlStmt);
	}

	private int getRiderMobileNumberActiveRidesCount(
			BigInteger riderMobileNumber) {
		String sqlStmt = "SELECT mobile_number FROM ride_offers WHERE  is_active=1 AND mobile_number="
				+ riderMobileNumber;
		final List<BigInteger> mobileNumbers = jdbcTemplate.queryForList(
				sqlStmt, BigInteger.class);
		if (mobileNumbers != null && !mobileNumbers.isEmpty()) {
			return mobileNumbers.size();
		}
		return 0;
	}

	@Override
	public List<OfferARideDTO> getOfferedRides(String pickupLoc, String dropLoc) {

		StringBuilder sb = new StringBuilder(
				"SELECT ro.ride_id,ro.rider_name,ro.start_time,(ro.offered_seats - count(opr.opt_id)) AS offered_seats,ro.vehicle_number,ro.meeting_point,ro.mobile_number,ro.pickup_location,ro.drop_location,ro.via_route FROM ride_offers ro LEFT JOIN opted_rides opr ON ro.is_active=1 AND opr.is_active=1 AND ro.is_active=opr.is_active AND ro.ride_id=opr.ride_id");

		if (StringUtils.hasText(pickupLoc)) {
			sb.append(" AND ");
			sb.append("(ro.pickup_location LIKE '");
			sb.append(pickupLoc.trim());
			sb.append("%' OR ro.via_route LIKE '%");
			sb.append(pickupLoc.trim());
			sb.append("%')");
		}
		if (StringUtils.hasText(dropLoc)) {
			sb.append(" AND ");
			sb.append("(ro.drop_location LIKE '");
			sb.append(dropLoc.trim());
			sb.append("%' OR ro.via_route LIKE '%");
			sb.append(dropLoc.trim());
			sb.append("%')");
		}
		sb.append(" GROUP BY opr.ride_id");

		return jdbcTemplate.query(sb.toString(), new OfferARideRowMapper());
	}

	@Override
	public List<OfferARideDTO> getMyOptedRides(BigInteger opterMobileNumber) {
		String selectStmt = "SELECT b.* FROM opted_rides a,ride_offers b WHERE a.is_active=1 AND a.is_active=b.is_active AND a.ride_id=b.ride_id AND a.mobile_number="
				+ opterMobileNumber;
		return jdbcTemplate.query(selectStmt, new OfferARideRowMapper());
	}
	
	private static class OfferARideRowMapper implements
			RowMapper<OfferARideDTO> {

		@Override
		public OfferARideDTO mapRow(ResultSet rs, int rowsAffected)
				throws SQLException {
			final OfferARideDTO offerARide = new OfferARideDTO();
			offerARide.setRiderName(rs.getString("rider_name"));
			offerARide.setDropLocation(rs.getString("drop_location"));
			offerARide.setMeetingPoint(rs.getString("meeting_point"));
			offerARide.setStartTime(rs.getString("start_time"));
			offerARide.setRideId(BigInteger.valueOf(rs.getLong("ride_id")));
			offerARide.setViaRoute(rs.getString("via_route"));
			offerARide.setVehicleNumber(rs.getString("vehicle_number"));
			offerARide.setOfferedSeats(rs.getInt("offered_seats"));
			offerARide.setPickupLocation(rs.getString("pickup_location"));
			offerARide.setMobileNumber(BigInteger.valueOf(rs
					.getLong("mobile_number")));
			return offerARide;
		}

	}


}
