package com.sharearide.dao;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.sharearide.model.OptARideDTO;
import com.sharearide.util.AppUtils;

@Repository
public class OptARideDAOImpl implements OptARideDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	@Transactional
	public boolean insertOptARide(OptARideDTO optARide) {
		if(!isOptedRideAllowed(optARide.getOptedRideId())){
			throw new RuntimeException("No vacancy in this ride. Please choose another ride.");
		}
		if(isOptedRideExists(optARide)){
			throw new RuntimeException("You have already opted for this ride.");
		}
		if (getRiderMobileNumberActiveRidesCount(optARide.getOpterMobileNumber()) > 0) {
			inActivateOldRidesOfAMobileNumber(optARide.getOpterMobileNumber());
		}
		String insertStmt = "INSERT INTO opted_rides (ride_id,opter_name,start_time,meeting_point,mobile_number,preferred_pickup_location,preferred_drop_location,preferred_via_route,createdDate,updatedDate,createdBy,updatedBy ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] params = new Object[] { optARide.getOptedRideId(),
				optARide.getOpterName(), optARide.getOptedStartTime(),
				optARide.getOptedMeetingPoint(),
				optARide.getOpterMobileNumber(),
				optARide.getOptedPickUpLocation(),
				optARide.getOptedDropLocation(),
				optARide.getPreferredViaRroute(), AppUtils.getTimestamp(),
				AppUtils.getTimestamp(), optARide.getOpterMobileNumber(),
				optARide.getOpterMobileNumber() };
		int rowsAffected = jdbcTemplate.update(insertStmt, params);
		return rowsAffected > 0 ? true : false;
	}

	private int inActivateOldRidesOfAMobileNumber(BigInteger opterMobileNumber) {
		String sqlStmt = "UPDATE opted_rides SET is_active=0 WHERE is_active=1 AND mobile_number="
				+ opterMobileNumber;
		return jdbcTemplate.update(sqlStmt);
	}
	
	private int getRiderMobileNumberActiveRidesCount(BigInteger opterMobileNumber) {
		String sqlStmt = "SELECT mobile_number FROM opted_rides WHERE  is_active=1 AND mobile_number="
				+ opterMobileNumber;
		final List<BigInteger> mobileNumbers = jdbcTemplate.queryForList(sqlStmt, BigInteger.class);
		if (mobileNumbers != null && !mobileNumbers.isEmpty()) {
			return mobileNumbers.size();
		}
		return 0;
	}
	
	private boolean isOptedRideExists(OptARideDTO optARide){
		
		StringBuilder sb = new StringBuilder("SELECT count(ride_id) FROM opted_rides WHERE is_active=1");

		if (StringUtils.hasText(String.valueOf(optARide.getOptedRideId().longValue()))) {
			sb.append(" AND ");
			sb.append("ride_id =");
			sb.append(String.valueOf(optARide.getOptedRideId().longValue()));			
		}
		if (StringUtils.hasText(String.valueOf(optARide.getOpterMobileNumber().longValue()))) {
			sb.append(" AND ");
			sb.append("mobile_number = ");
			sb.append(String.valueOf(optARide.getOpterMobileNumber().longValue()));			
		}
		Integer records =jdbcTemplate.queryForObject(sb.toString(), Integer.class);
		
		return (records > 0) ? true:false;		
	}
	private boolean isOptedRideAllowed(BigInteger rideID) {
		String offerRidesStmt = "SELECT offered_seats FROM ride_offers WHERE  is_active=1 AND ride_id="
				+ rideID;
		Integer offeredSeats = jdbcTemplate.queryForObject(offerRidesStmt,Integer.class);
		String optRidesStmt = "SELECT count(ride_id) FROM opted_rides WHERE  is_active=1 AND ride_id="
				+ rideID;
		final Integer occupiedSeats = jdbcTemplate.queryForObject(optRidesStmt,Integer.class);
		if (occupiedSeats < offeredSeats) {
			return true;
		} else if (occupiedSeats >= offeredSeats) {
			return false;
		}
		return true;
	}

	@Override
	public List<OptARideDTO> getOptedRides(BigInteger mobileNumber) {
		String selectStmt = "SELECT a.* FROM opted_rides a,ride_offers b WHERE a.is_active=1 AND a.is_active=b.is_active AND a.ride_id=b.ride_id AND b.mobile_number="
				+ mobileNumber;
		return jdbcTemplate.query(selectStmt, new OptedRidesRowMapper());
	}

	private static class OptedRidesRowMapper implements RowMapper<OptARideDTO> {

		@Override
		public OptARideDTO mapRow(ResultSet rs, int rowsAffected)
				throws SQLException {
			final OptARideDTO optARideDTO = new OptARideDTO();
			optARideDTO.setOpterName(rs.getString("opter_name"));
			optARideDTO.setOptedDropLocation(rs
					.getString("preferred_drop_location"));
			optARideDTO.setOptedMeetingPoint(rs.getString("meeting_point"));
			optARideDTO.setOptedPickUpLocation(rs
					.getString("preferred_pickup_location"));
			optARideDTO
					.setOptedRideId(BigInteger.valueOf(rs.getLong("ride_id")));
			optARideDTO.setOptedStartTime(rs.getString("start_time"));
			optARideDTO.setOpterMobileNumber(BigInteger.valueOf(rs
					.getLong("mobile_number")));
			optARideDTO.setPreferredViaRroute(rs
					.getString("preferred_via_route"));
			return optARideDTO;
		}

	}

}
