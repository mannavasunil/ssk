package com.sharearide.dao;

import java.math.BigInteger;
import java.util.List;

import com.sharearide.model.OfferARideDTO;

public interface OfferARideDAO {
	public boolean insertOfferARide(OfferARideDTO offerARide);
	
	public List<OfferARideDTO> getOfferedRides(String pickupLoc, String dropLoc);
	
	public List<OfferARideDTO> getMyOptedRides(BigInteger opterMobileNumber);
	
}
