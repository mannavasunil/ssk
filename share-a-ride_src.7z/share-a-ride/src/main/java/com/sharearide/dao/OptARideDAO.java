package com.sharearide.dao;

import java.math.BigInteger;
import java.util.List;

import com.sharearide.model.OptARideDTO;

public interface OptARideDAO {
	public boolean insertOptARide(OptARideDTO optARide);

	public List<OptARideDTO> getOptedRides(final BigInteger mobileNumber);
}
