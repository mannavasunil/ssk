package com.sharearide.web;

import java.math.BigInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sharearide.model.OptARideDTO;
import com.sharearide.services.OptARideService;
import com.sharearide.util.AppUtils;
import com.sharearide.util.RestResponse;
import com.sharearide.util.ValidationUtils;
@Controller
public class OptARideController {
	@Autowired
	private OptARideService optARideService;

	private final static Logger logger = Logger.getLogger(OptARideController.class);

	@RequestMapping(value = "/saveOptedRide",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody RestResponse createRide(@RequestBody OptARideDTO optARideDTO ) {
		if (logger.isDebugEnabled())
			logger.debug("OptARideController.createRide");
		
		ValidationUtils.validateOptARideData(optARideDTO);
		
		return AppUtils.buildRestResponse( optARideService.insertOptARide(optARideDTO));
	}
	@RequestMapping(value = "/getOptedRides", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody RestResponse searchRides(@RequestParam(required=true) BigInteger riderMobileNumber){
		if (logger.isDebugEnabled())
			logger.debug("OptARideController.searchRides:::pickupLocation  "+riderMobileNumber);
		
		
		return AppUtils.buildRestResponse(optARideService.getOptedRides(riderMobileNumber));		
	}
}
