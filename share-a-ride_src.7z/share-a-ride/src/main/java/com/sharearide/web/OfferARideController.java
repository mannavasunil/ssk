package com.sharearide.web;

import java.math.BigInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sharearide.model.OfferARideDTO;
import com.sharearide.services.OfferARideService;
import com.sharearide.util.AppUtils;
import com.sharearide.util.RestResponse;
import com.sharearide.util.ValidationUtils;

@Controller
public class OfferARideController {

	@Autowired
	private OfferARideService offerARideService;

	private final static Logger logger = Logger
			.getLogger(OfferARideController.class);

	@RequestMapping(value = "/offerRide", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody RestResponse createRide(@RequestBody OfferARideDTO offerARideDTO) {
		if (logger.isDebugEnabled())
			logger.debug("OfferARideController.createRide");

		ValidationUtils.validateOfferARideData(offerARideDTO);
		return AppUtils.buildRestResponse(offerARideService.insertOfferARide(offerARideDTO));
	}

	@RequestMapping(value = "/searchRide", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody RestResponse searchRides(
			@RequestParam String pickupLocation,
			@RequestParam String dropLocation) {
		if (logger.isDebugEnabled())
			logger.debug("OfferARideController.searchRides:::pickupLocation  "
					+ pickupLocation + "  dropLocation  " + dropLocation);

		return AppUtils.buildRestResponse(offerARideService.getOfferedRides(pickupLocation, dropLocation));
	}

	@RequestMapping(value = "/getMyRides", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody RestResponse getMyRides(
			@RequestParam(required=true) BigInteger opterMobileNumber) {
		if (logger.isDebugEnabled())
			logger.debug("OfferARideController.getMyRides:::opterMobileNumber  "	+ opterMobileNumber);

		return AppUtils.buildRestResponse(offerARideService.getMyOptedRides(opterMobileNumber));
	}
}
