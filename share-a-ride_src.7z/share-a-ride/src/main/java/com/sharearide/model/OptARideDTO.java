package com.sharearide.model;

import java.io.Serializable;
import java.math.BigInteger;

public class OptARideDTO implements Serializable {

	private static final long serialVersionUID = 331897713741805035L;	
	private String opterName;
	private BigInteger optedRideId;
	private String optedStartTime;
	private String optedMeetingPoint;
	private BigInteger opterMobileNumber;
	private String optedPickUpLocation;
	private String optedDropLocation;
	private String preferredViaRroute;
	public BigInteger getOptedRideId() {
		return optedRideId;
	}
	public void setOptedRideId(BigInteger optedRideId) {
		this.optedRideId = optedRideId;
	}
	public String getOptedStartTime() {
		return optedStartTime;
	}
	public void setOptedStartTime(String optedStartTime) {
		this.optedStartTime = optedStartTime;
	}
	public String getOptedMeetingPoint() {
		return optedMeetingPoint;
	}
	public void setOptedMeetingPoint(String optedMeetingPoint) {
		this.optedMeetingPoint = optedMeetingPoint;
	}
	public BigInteger getOpterMobileNumber() {
		return opterMobileNumber;
	}
	public void setOpterMobileNumber(BigInteger opterMobileNumber) {
		this.opterMobileNumber = opterMobileNumber;
	}
	public String getOptedPickUpLocation() {
		return optedPickUpLocation;
	}
	public void setOptedPickUpLocation(String optedPickUpLocation) {
		this.optedPickUpLocation = optedPickUpLocation;
	}
	public String getOptedDropLocation() {
		return optedDropLocation;
	}
	public void setOptedDropLocation(String optedDropLocation) {
		this.optedDropLocation = optedDropLocation;
	}
	public String getPreferredViaRroute() {
		return preferredViaRroute;
	}
	public void setPreferredViaRroute(String preferredViaRroute) {
		this.preferredViaRroute = preferredViaRroute;
	}
	
	public String getOpterName() {
		return opterName;
	}
	public void setOpterName(String opterName) {
		this.opterName = opterName;
	}
	@Override
	public String toString() {
		return "OptARideDTO [opterName=" + opterName + ", optedRideId="
				+ optedRideId + ", optedStartTime=" + optedStartTime
				+ ", optedMeetingPoint=" + optedMeetingPoint
				+ ", opterMobileNumber=" + opterMobileNumber
				+ ", optedPickUpLocation=" + optedPickUpLocation
				+ ", optedDropLocation=" + optedDropLocation
				+ ", preferredViaRroute=" + preferredViaRroute + "]";
	}
	
	
}
