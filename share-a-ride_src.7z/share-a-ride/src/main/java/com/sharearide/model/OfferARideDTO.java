package com.sharearide.model;

import java.io.Serializable;
import java.math.BigInteger;

public class OfferARideDTO implements Serializable{

	private static final long serialVersionUID = -5495947737247368162L;
	
	private BigInteger rideId;
	private String riderName;
	private String startTime;
	private int offeredSeats;
	private String vehicleNumber;
	private String meetingPoint;
	private BigInteger mobileNumber;
	private String pickupLocation;
	private String dropLocation;
	private String viaRoute;	
	private int isActive = 1;
	public BigInteger getRideId() {
		return rideId;
	}
	public void setRideId(BigInteger rideId) {
		this.rideId = rideId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public int getOfferedSeats() {
		return offeredSeats;
	}
	public void setOfferedSeats(int offeredSeats) {
		this.offeredSeats = offeredSeats;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getMeetingPoint() {
		return meetingPoint;
	}
	public void setMeetingPoint(String meetingPoint) {
		this.meetingPoint = meetingPoint;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPickupLocation() {
		return pickupLocation;
	}
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}
	public String getDropLocation() {
		return dropLocation;
	}
	public void setDropLocation(String dropLocation) {
		this.dropLocation = dropLocation;
	}
	public String getViaRoute() {
		return viaRoute;
	}
	public void setViaRoute(String viaRoute) {
		this.viaRoute = viaRoute;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	public String getRiderName() {
		return riderName;
	}
	public void setRiderName(String riderName) {
		this.riderName = riderName;
	}
	@Override
	public String toString() {
		return "OfferARideDTO [rideId=" + rideId + ", riderName=" + riderName
				+ ", startTime=" + startTime + ", offeredSeats=" + offeredSeats
				+ ", vehicleNumber=" + vehicleNumber + ", meetingPoint="
				+ meetingPoint + ", mobileNumber=" + mobileNumber
				+ ", pickupLocation=" + pickupLocation + ", dropLocation="
				+ dropLocation + ", viaRoute=" + viaRoute + ", isActive="
				+ isActive + "]";
	}
	

}
